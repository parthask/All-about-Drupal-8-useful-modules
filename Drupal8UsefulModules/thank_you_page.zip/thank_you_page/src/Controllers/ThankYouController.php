<?php

namespace Drupal\thank_you_page\Controller

use Drupal\Core\Controller\ControllerBase;

class ThankYouController extends ControllerBase {

	function sayThankYou(){
		return array(
				'#title' => 'Thanks giving page',
				'#markup' => 'Thanks a ton for being here! We really appreciate your visit here. Hope you will come again.'
			);
	}
}
