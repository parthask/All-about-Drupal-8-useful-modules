<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'fan', 'yi', 'tan', 'lei', 'yong', NULL, 'jin', 'she', 'yin', 'ji', NULL, 'su', NULL, NULL, NULL, 'wang',
  0x10 => 'mian', 'su', 'yi', 'shai', 'xi', 'ji', 'luo', 'you', 'mao', 'zha', 'sui', 'zhi', 'bian', 'li', NULL, NULL,
  0x20 => NULL, NULL, NULL, NULL, NULL, 'qiao', 'guan', 'xi', 'zhen', 'yong', 'nie', 'jun', 'xie', 'yao', 'xie', 'zhi',
  0x30 => 'neng', NULL, 'si', 'long', 'chen', 'mi', 'que', 'dan', 'shan', NULL, NULL, NULL, 'su', 'xie', 'bo', 'ding',
  0x40 => 'zu', NULL, 'shu', 'she', 'han', 'tan', 'gao', NULL, NULL, NULL, 'na', 'mi', 'xun', 'men', 'jian', 'cui',
  0x50 => 'jue', 'he', 'fei', 'shi', 'che', 'shen', 'nu', 'ping', 'man', NULL, NULL, NULL, NULL, 'yi', 'chou', NULL,
  0x60 => 'ku', 'bao', 'lei', 'ke', 'sha', 'bi', 'sui', 'ge', 'pi', 'yi', 'xian', 'ni', 'ying', 'zhu', 'chun', 'feng',
  0x70 => 'xu', 'piao', 'wu', 'liao', 'cang', 'zou', 'zuo', 'bian', 'yao', 'huan', 'pai', 'xiu', NULL, 'lei', 'qing', 'xiao',
  0x80 => 'jiao', 'guo', NULL, NULL, 'yan', 'xue', 'zhu', 'heng', 'ying', 'xi', NULL, NULL, 'lian', 'xian', 'huan', 'yin',
  0x90 => NULL, 'lian', 'shan', 'cang', 'bei', 'jian', 'shu', 'fan', 'dian', NULL, 'ba', 'yu', NULL, NULL, 'nang', 'lei',
  0xA0 => 'yi', 'dai', NULL, 'chan', 'chao', 'gan', 'jin', 'nen', NULL, NULL, NULL, 'liao', 'mo', 'you', NULL, 'liu',
  0xB0 => 'han', NULL, 'yong', 'jin', 'chi', 'ren', 'nong', NULL, NULL, 'hong', 'tian', NULL, 'ai', 'gua', 'biao', 'bo',
  0xC0 => 'qiong', NULL, 'shu', 'chui', 'hui', 'chao', 'fu', 'hui', 'e', 'wei', 'fen', 'tan', NULL, 'lun', 'he', 'yong',
  0xD0 => 'hui', NULL, 'yu', 'zong', 'yan', 'qiu', 'zhao', 'jiong', 'tai', NULL, NULL, NULL, NULL, NULL, NULL, 'tui',
  0xE0 => 'lin', 'jiong', 'zha', 'xing', 'hu', NULL, 'xu', NULL, NULL, NULL, 'cui', 'qing', 'mo', NULL, 'zao', 'beng',
  0xF0 => 'chi', NULL, NULL, 'yan', 'ge', 'mo', 'bei', 'juan', 'die', 'zhao', NULL, 'wu', 'yan', NULL, 'jue', 'xian',
];
