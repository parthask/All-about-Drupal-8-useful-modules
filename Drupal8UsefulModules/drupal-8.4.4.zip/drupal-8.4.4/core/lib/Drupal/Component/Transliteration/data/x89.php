<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ji', 'zhi', 'gua', 'ken', 'qi', 'ti', 'ti', 'fu', 'chong', 'xie', 'bian', 'die', 'kun', 'duan', 'xiu', 'xiu',
  0x10 => 'he', 'yuan', 'bao', 'bao', 'fu', 'yu', 'tuan', 'yan', 'hui', 'bei', 'chu', 'lu', 'pao', 'dan', 'yun', 'ta',
  0x20 => 'gou', 'da', 'huai', 'rong', 'yuan', 'ru', 'nai', 'jiong', 'suo', 'ban', 'tui', 'chi', 'sang', 'niao', 'ying', 'jie',
  0x30 => 'qian', 'huai', 'ku', 'lian', 'lan', 'li', 'zhe', 'shi', 'lu', 'yi', 'die', 'xie', 'xian', 'wei', 'biao', 'cao',
  0x40 => 'ji', 'qiang', 'sen', 'bao', 'xiang', 'bi', 'fu', 'jian', 'zhuan', 'jian', 'cui', 'ji', 'dan', 'za', 'fan', 'bo',
  0x50 => 'xiang', 'xin', 'bie', 'rao', 'man', 'lan', 'ao', 'ze', 'gui', 'cao', 'sui', 'nong', 'chan', 'lian', 'bi', 'jin',
  0x60 => 'dang', 'shu', 'tan', 'bi', 'lan', 'pu', 'ru', 'zhi', 'dui', 'shu', 'wa', 'shi', 'bai', 'xie', 'bo', 'chen',
  0x70 => 'lai', 'long', 'xi', 'xian', 'lan', 'zhe', 'dai', 'ju', 'zan', 'shi', 'jian', 'pan', 'yi', 'lan', 'ya', 'xi',
  0x80 => 'xi', 'yao', 'feng', 'tan', 'fu', 'fiao', 'fu', 'ba', 'he', 'ji', 'ji', 'jian', 'guan', 'bian', 'yan', 'gui',
  0x90 => 'jue', 'pian', 'mao', 'mi', 'mi', 'mie', 'shi', 'si', 'chan', 'luo', 'jue', 'mi', 'tiao', 'lian', 'yao', 'zhi',
  0xA0 => 'jun', 'xi', 'shan', 'wei', 'xi', 'tian', 'yu', 'lan', 'e', 'du', 'qin', 'pang', 'ji', 'ming', 'ying', 'gou',
  0xB0 => 'qu', 'zhan', 'jin', 'guan', 'deng', 'jian', 'luo', 'qu', 'jian', 'wei', 'jue', 'qu', 'luo', 'lan', 'shen', 'di',
  0xC0 => 'guan', 'jian', 'guan', 'yan', 'gui', 'mi', 'shi', 'chan', 'lan', 'jue', 'ji', 'xi', 'di', 'tian', 'yu', 'gou',
  0xD0 => 'jin', 'qu', 'jiao', 'qiu', 'jin', 'cu', 'jue', 'zhi', 'chao', 'ji', 'gu', 'dan', 'zi', 'di', 'shang', 'hua',
  0xE0 => 'quan', 'ge', 'shi', 'jie', 'gui', 'gong', 'chu', 'jie', 'hun', 'qiu', 'xing', 'su', 'ni', 'ji', 'lu', 'zhi',
  0xF0 => 'zha', 'bi', 'xing', 'hu', 'shang', 'gong', 'zhi', 'xue', 'chu', 'xi', 'yi', 'li', 'jue', 'xi', 'yan', 'xi',
];
